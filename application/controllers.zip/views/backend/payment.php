<?php
    $this->load->view('backend/header');
    $this->load->view('backend/sidebar'); 
?>

        <div class="page-wrapper">
<!--<style>
    .file_prev img {
    height: 100px;
    width: auto;
    margin-bottom: 15px;
    margin-right: 10px;
}
</style>-->

            <div class="container-fluid p-t-10">

            <div class="flashmessage"></div>

                <div class="row m-b-10"> 

                    <div class="col-12">

                        <button type="button" class="btn btn-primary"><i class="fa fa-bars"></i><a href="<?php echo base_url('Medicine/View');?>" class="text-white"><i class="" aria-hidden="true"></i>Supplier Payment</a></button>

                    </div>

                </div>

                <div class="row">

                    <div class="col-lg-12">

                        <div class="card card-outline-info">
                            <div class="card-header">                                
                                <!--<h4 class="m-b-0 text-white">New Medicine <span class="pull-right">--><?php date_default_timezone_set("Asia/Dhaka"); echo date("l jS \of F Y h:i:s A") ?></span></h4>
                            </div>
                            <div class="card-body">
                                <form action="Save" method="post" class="form-horizontal" enctype="multipart/form-data" accept-charset="utf-8" id="accountID">

                                    <div class="form-body">

                                        <span class="m-t-30 m-b-40"></span>

                                        <div class="row">
                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Company Name</label>

                                                    <div class="col-md-9 col-sm-12">
                                                        <select class="js-supplier-data-ajax form-control" name="supplier" style="width:100%">
                                                           <!--<?php foreach($supplierList as $value): ?>
                                                            <option value="<?php echo $value->s_id; ?>"><?php echo $value->s_name; ?></option>
                                                            <?php endforeach; ?> -->       
                                                        </select>

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Description</label>

                                                    <div class="col-md-9 col-sm-12">

                                                        <input type="text" name="details" class="form-control" placeholder="Details" >

                                                    </div>

                                                </div>

                                            </div>                                            
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Transaction Mood</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <select name="mtype" id="mtype" class="form-control">
                                                            <option value="">Select Here</option>
                                                            <option value="Bank">Bank</option>
                                                            <option value="Cash">Cash</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12" id="cheque">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Cheque/Pay Order No *</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="text" name="cheque" class="form-control" placeholder="" required>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6 col-sm-12" id="issuedate">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Date *</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="text" name="issuedate" class="form-control datepicker" placeholder="" value="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12" id='bankid'>
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Bank</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <select class="select2 form-control" name="bankid" style="width:100%">
                                                           <?php foreach($bankinfo as $value): ?>
                                                            <option value="<?php echo $value->bank_id; ?>"><?php echo $value->bank_name; ?></option>
                                                            <?php endforeach; ?>       
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>




                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Payment Amount</label>

                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="number" name="amount" class="form-control mrp" placeholder="Amount.." required>
                                                    </div>

                                                </div>

                                            </div>
                                            <br>
                                            <div class="col-md-5 col-sm-12">

                                            </div>

                                            </div>
                                        </div>

                                        <!--/row-->

                                    

                                    <hr>

                                    <div class="form-actions text-center">

                                        <div class="row">

                                            <div class=" col-md-12 ">

                                                <button type="submit" class="btn btn-info">Submit</button>

                                                <button type="button" class="btn btn-inverse">Cancel</button>    

                                            </div>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>

            </div>           

            <footer class="footer"> © 2017 GenIT Bangladesh </footer>

        </div>
       <script type="text/javascript">
            $(document).ready(function () {           
            $('#accountID #mtype').on('change', function(e) {

                e.preventDefault(e);

                // Get the record's ID via attribute  

                var type = $('#mtype').val();
                console.log(type);
                if(type =='Bank'){

                    console.log(type);

                    $('#cheque').show();

                    $('#issuedate').show();

                    $('#bankid').show();
                } 

                else if(type =='Cash'){

                    console.log(type);

                    $('#cheque').hide();

                    $('#issuedate').hide();

                    $('#bankid').hide();  
                }

            });

                    $('#cheque').hide();

                    $('#issuedate').hide();

                    $('#bankid').hide();                
            });
        </script>
<script type="text/javascript">
    $(document).ready(function () {
	$(".js-supplier-data-ajax").select2({

	    ajax: {
	        url: "<?php echo base_url(); ?>purchase/GetSupplierByid",
	        dataType: 'json',
	        type: "GET",
	        data: function (term) {
	            return {
	                param: term.term
	            };
	        },
	        processResults: function (data) {
	            
	            return {
		            results: $.map(data, function (item) {
		                return {
		                    text: item.s_name,
		                    id: item.s_id
		                };
		            })
		        };
	        },
	    }
	});
	});
</script>

<?php 

    $this->load->view('backend/footer');

?>
<?php
  $this->load->view('backend/header');
  $this->load->view('backend/sidebar'); 
?>
<div class="page-wrapper">
  <div class="container-fluid" style="padding-top: 9px;">
    <div class="row">
      <div class="col-12">
        <div class="card card-outline-info" style="border-radius: none; width: 210mm; height: 297mm;">
          <div class="card-body barcode-table-card">
            <table class="table barcode-table">
              <tbody>
                <tr>
                <td>
                <h4 class='card-title' style='text-align:center; margin-bottom: -10px;'><strong>gfgdfgd</strong></h4>
                <div class='card-body'>
                <h4 class='card-title' style='text-align:center'>gdfg &nbsp; &nbsp; &nbsp; dfgd</h4>
                <img class='' src='https://i.imgur.com/5dgP1EW.png' alt='Card image' height='120px' width='320px'>
                <p style='text-align:center'>$mvalue->expire_date</p>
                </div>
                </td>
                <td>
                <h4 class='card-title' style='text-align:center; margin-bottom: -10px;'><strong>gfgdfgd</strong></h4>
                <div class='card-body'>
                <h4 class='card-title' style='text-align:center'>gdfg &nbsp; &nbsp; &nbsp; dfgd</h4>
                <img class='' src='https://i.imgur.com/5dgP1EW.png' alt='Card image' height='120px' width='320px'>
                <p style='text-align:center'>$mvalue->expire_date</p>
                </div>
                </td>
                <td>
                <h4 class='card-title' style='text-align:center; margin-bottom: -10px;'><strong>gfgdfgd</strong></h4>
                <div class='card-body'>
                <h4 class='card-title' style='text-align:center'>gdfg &nbsp; &nbsp; &nbsp; dfgd</h4>
                <img class='' src='https://i.imgur.com/5dgP1EW.png' alt='Card image' height='120px' width='320px'>
                <p style='text-align:center'>$mvalue->expire_date</p>
                </div>
                </td>
                <td>
                <h4 class='card-title' style='text-align:center; margin-bottom: -10px;'><strong>gfgdfgd</strong></h4>
                <div class='card-body'>
                <h4 class='card-title' style='text-align:center'>gdfg &nbsp; &nbsp; &nbsp; dfgd</h4>
                <img class='' src='https://i.imgur.com/5dgP1EW.png' alt='Card image' height='120px' width='320px'>
                <p style='text-align:center'>$mvalue->expire_date</p>
                </div>
                </td>
              </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('backend/footer');
?>

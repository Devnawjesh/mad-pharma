<?php
    $this->load->view('backend/header');
    $this->load->view('backend/sidebar'); 
?>

        <div class="page-wrapper">
<style>
.file_prev img {height: 44px;width: auto;max-width: 100%;margin-bottom: 0px;margin-right: 0px;margin-top: 0px;}
</style>

            <div class="container-fluid p-t-10">

            <div class="flashmessage"></div>

                <div class="row m-b-10"> 

                    <div class="col-12">

                        <button type="button" class="btn btn-primary"><i class="fa fa-bars"></i><a href="<?php echo base_url('Medicine/View');?>" class="text-white"><i class="" aria-hidden="true"></i> Manage Medicine </a></button>

                    </div>

                </div>

                <div class="row">

                    <div class="col-lg-12">

                        <div class="card card-outline-info">
                            <div class="card-header">                                
                                <h4 class="m-b-0 text-white">New Medicine <span class="pull-right"><?php date_default_timezone_set("Asia/Dhaka"); echo date("l jS \of F Y h:i:s A") ?></span></h4>
                            </div>
                            <div class="card-body">
                                <form action="Save" method="post" class="form-horizontal" enctype="multipart/form-data" accept-charset="utf-8">

                                    <div class="form-body">

                                        <span class="m-t-30 m-b-40"></span>

                                        <div class="row">
                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Company Name</label>

                                                    <div class="col-md-9 col-sm-12">
                                                        <select class="js-supplier-data-ajax form-control" name="supplier" style="width:100%">
                                                           <!--<?php foreach($supplierList as $value): ?>
                                                            <option value="<?php echo $value->s_id; ?>"><?php echo $value->s_name; ?></option>
                                                            <?php endforeach; ?> -->       
                                                        </select>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Product Name</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="text" name="product_name" class="form-control" placeholder="Product Name" required minlength="1">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Generic Name</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="text" name="generic_name" class="form-control" placeholder="Generic Name" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Barcode Number</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="number" name="barcode" class="form-control" placeholder="" value="<?php echo rand(100000000,1500000000)?>" required >
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Strength</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="text" name="strength" class="form-control" placeholder="Strength" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Form</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <select name="form" class="select2" id="" style="width:100%" required>
                                                            <option value="Tablet">Tablet</option>
                                                            <option value="Capsules">Capsule</option>
                                                            <option value="Injection">Injection</option>
                                                            <option value="Eye Drop">Eye Drop</option>
                                                            <option value="Suspension">Suspension</option>
                                                            <option value="Cream">Cream</option>
                                                            <option value="Saline">Saline</option>
                                                            <option value="Inhaler">Inhaler</option>
                                                            <option value="Powder">Powder</option>
                                                            <option value="Spray">Spray</option>
                                                            <option value="Paediatric Drop">Paediatric Drop</option>
                                                            <option value="Nebuliser Solution">Nebuliser Solution</option>
                                                            <option value="Powder for Suspension">Powder for Suspension</option>
                                                        </select>

                                                    </div>

                                                </div>

                                            </div>


                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Trade Price</label>

                                                    <div class="col-md-9 col-sm-12">

                                                        <input type="number" name="trade_price" class="form-control" placeholder="Trade Price" required>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">M.R.P.</label>

                                                    <div class="col-md-9 col-sm-12">

                                                        <input type="number" name="mrp" class="form-control mrp" placeholder="M.R.P." required>

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Box Size</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="number" name="box_size" class="form-control boxsize" placeholder="Box Size" required>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Box Pirce</label>

                                                    <div class="col-md-9 col-sm-12">

                                                        <input type="number" name="box_price" class="form-control totalboxprice" placeholder="Box Pirce">

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-md-6 col-sm-12">

                                                <div class="form-group row">

                                                    <label class="control-label text-right col-md-3 col-sm-12">Expire Date</label>

                                                    <div class="col-md-9 col-sm-12">

                                                        <input type="text" name="expire_date" class="form-control" placeholder="Expire Date" id="datepicker" required>

                                                    </div>

                                                </div>

                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Short Quantity</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input type="number" name="shortstock" class="form-control" placeholder="Short Quantity" id="shortstock" required>
                                                    </div>
                                                </div>
                                            </div>
<!--                                        <div class="col-md-9 col-md-offset-3">
                                            <div class="file_prev"></div>
                                            <label for="user_image" class="custom-file-upload">Upload image</label>
                                        </div>
                                        <div class="col-md-9 col-md-offset-3">
                                            <input type="file" class="" id="user_image" name="user_image" aria-describedby="fileHelp" required>
                                        </div>-->
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                   
                                                    <label class="control-label text-right col-md-3 col-sm-3">Product Image</label>
                                                    <div class="col-md-7 col-sm-7">
                                                        <input type="file" name="product_image" id="user_image" class="form-control" aria-describedby="fileHelp">
                                                    </div>
                                                    <div class="col-md-2 col-sm-2">
                                                        <div class="file_prev "></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Side Effect</label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <textarea class="form-control" name="side_effect" rows="1"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="col-md-3 col-sm-12"></label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input name="favourite" class="custom-control-input" value="1" type="checkbox" id="regular_customer">
                                                        <label for="regular_customer">Add To Favourite</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <div class="form-group row">
                                                    <label class="control-label text-right col-md-3 col-sm-12">Discount </label>
                                                    <div class="col-md-9 col-sm-12">
                                                        <input name="discount" class="custom-control-input" value="1" type="radio" id="discount_yes" checked>
                                                        <label for="discount_yes">Yes</label>
                                                        <input name="discount" class="custom-control-input" value="0" type="radio" id="discount_no">
                                                        <label for="discount_no">No</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!--/row-->

                                    </div>

                                    <hr>

                                    <div class="form-actions text-center">

                                        <div class="row">

                                            <div class=" col-md-12 ">

                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-info">Submit</button>

                                                <button type="button" class="btn btn-inverse">Cancel</button> 
                                                </div>   

                                                <br>
                                                <br>

                                            </div>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>

            </div>           

            <footer class="footer"> © 2017 GenIT Bangladesh </footer>

        </div>
                <script type="text/javascript">
                    $('.boxsize , .mrp').on('input', function() {
                        var boxprice = $('.boxsize').val();
                        var mrp = $('.mrp').val();
                        console.log('mrp');
                        $('.totalboxprice').val((boxprice * mrp ? boxprice * mrp : 0).toFixed(2));
        
                    });
                </script>
<script type="text/javascript">
    $(document).ready(function () {
	$(".js-supplier-data-ajax").select2({

	    ajax: {
	        url: "<?php echo base_url(); ?>purchase/GetSupplierByid",
	        dataType: 'json',
	        type: "GET",
	        data: function (term) {
	            return {
	                param: term.term
	            };
	        },
	        processResults: function (data) {
	            
	            return {
		            results: $.map(data, function (item) {
		                return {
		                    text: item.s_name,
		                    id: item.s_id
		                };
		            })
		        };
	        },
	    }
	});
	});
</script>
<script>
$("#user_image").on("change", function() {
    if (typeof FileReader == "undefined") {
        alert("Your browser doesn't support HTML5, Please upgrade your browser");
    } else {
        var container = $(".file_prev");
        //remove all previous selected files
        container.empty();

        //create instance of FileReader
        var reader = new FileReader();
        reader.onload = function(e) {
            $("<img />", {
                src: e.target.result
            }).appendTo(container);
        };
        reader.readAsDataURL($(this)[0].files[0]);
    }
});
    </script>
<?php 

    $this->load->view('backend/footer');

?>
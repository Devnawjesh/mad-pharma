<?php

	class Sales_model extends CI_Model{


	function __consturct(){
	parent::__construct();
	
	}
/*    public function Add_user_info($data){
		$this->db->insert('user',$data);
	}*/
    public function getTodaysSale($date){
        $sql = "SELECT `sales`.*,
        `customer`.`c_name`
        FROM `sales`
        LEFT JOIN `customer` ON `sales`.`cus_id`=`customer`.`c_id`
        WHERE `sales`.`create_date`='$date'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }
    public function getByInvoiceFromToEnd($start,$end){
        $sql = "SELECT `sales`.*,
        `customer`.`c_name`
        FROM `sales`
        LEFT JOIN `customer` ON `sales`.`cus_id`=`customer`.`c_id`
        WHERE `create_date` BETWEEN '$start' AND '$end'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }
    public function getSalesReport(){
        $sql = "SELECT `sales`.*,
        `customer`.`c_name`
        FROM `sales`
        LEFT JOIN `customer` ON `sales`.`cus_id`=`customer`.`c_id`";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    } 
    public function getSalesReportForInvoice($id){
        $sql = "SELECT `sales`.*,
        `customer`.`c_name`
        FROM `sales`
        LEFT JOIN `customer` ON `sales`.`cus_id`=`customer`.`c_id`
        WHERE `sales`.`sale_id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result;
    }  
    public function getSalesDetailsForInvoice($id){
        $sql = "SELECT `sales_details`.*,
        `medicine`.`product_id`,`product_name`,`mrp`
        FROM `sales_details`
        LEFT JOIN `medicine` ON `sales_details`.`mid`=`medicine`.`product_id`
        WHERE `sales_details`.`sale_id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    } 
    public function getTodaysPurchase($date){
        $sql = "SELECT `purchase`.*,
        `supplier`.`s_name`
        FROM `purchase`
        LEFT JOIN `supplier` ON `purchase`.`sid`=`supplier`.`s_id`
        WHERE `purchase`.`entry_date`='$date'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    } 
    public function getPurchaseReport(){
        $sql = "SELECT `purchase`.*,
        `supplier`.`s_name`
        FROM `purchase`
        LEFT JOIN `supplier` ON `purchase`.`sid`=`supplier`.`s_id`";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }


    // Get details by invoice number
    public function getByInvoice($invoiceID) {

    $sql = "SELECT `mid` AS `medicine_id`, `qty`, `rate`, `total_price`, `discount`, `total_discount`, (SELECT `medicine`.`product_name` FROM `medicine` WHERE `medicine_id` = `medicine`.`product_id`) AS 'medicine_name'
            FROM `sales_details`
            WHERE `sale_id` IN (SELECT `sale_id` FROM `sales` WHERE `invoice_no` = '$invoiceID')";

    /*$sql = "SELECT `mid`, `qty`, `rate`, `total_price`, `discount`, `total_discount`,
            `medicine`.`product_name`
            FROM `sales_details`
            LEFT JOIN `medicine` ON `medicine`.`product_id` = `sales_details`.`mid`
            WHERE `sale_id` IN (SELECT `sale_id` FROM `sales` WHERE `invoice_no` = '65168533')";*/

        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;        
    }      
}
?>
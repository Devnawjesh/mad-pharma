<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Sales extends CI_Controller {



	    function __construct() {

        parent::__construct();

        $this->load->database();

        $this->load->model('login_model');

        $this->load->model('user_model');

        $this->load->model('medicine_model');
        $this->load->model('customer_model');
        $this->load->model('supplier_model');
        $this->load->model('sales_model');
        $this->load->model('purchase_model');
        $this->load->model('configuration_model');
    }

	public function index()

	{
		#Redirect to Admin dashboard after authentication
		if ($this->session->userdata('user_login_access') != 1)
            redirect(base_url() . 'login', 'refresh');
        if ($this->session->userdata('user_login_access') == 1)
          $data= array();
        redirect('dashboard/Dashboard');
	}

/*    public function Create(){

        $this->load->view('backend/Add_supplier');

    }*/

   public function Today_report(){
       if($this->session->userdata('user_login_access') != False) {
       $today = date('d-m-Y');
       $date = strtotime($today);
        $data['todaysreport'] = $this->sales_model->getTodaysSale($date);
        $data['purchasereport'] = $this->sales_model->getTodaysPurchase($date);
        $this->load->view('backend/today_sale',$data);
        }
    else{
		redirect(base_url() , 'refresh');
	}          

    } 

   public function Sales_report(){

       if($this->session->userdata('user_login_access') != False) {

        $data['salesreport'] = $this->sales_model->getSalesReport();

        $this->load->view('backend/sales_report',$data);

        }

    else{

		redirect(base_url() , 'refresh');

	}           

    } 

   public function Purchase_report(){
       if($this->session->userdata('user_login_access') != False) {
        $data['purchasereport'] = $this->sales_model->getPurchaseReport();
        $this->load->view('backend/purchase_report',$data);
        }

    else{
		redirect(base_url() , 'refresh');
	}       
    }  

   public function Purchase_Return(){
       if($this->session->userdata('user_login_access') != False) {
        $this->load->view('backend/purchase_return');
        }

    else{
		redirect(base_url() , 'refresh');
	}       
    } 

   public function Sales_Return(){
       // $data['purchasereport'] = $this->sales_model->getPurchaseReport();
        $this->load->view('backend/sales_return');
    } 

   public function Purchase_Return_Invoice(){
       $invoice = $this->input->post('pinvoice');
      $purchasereport = $this->sales_model->getPurchaseReportForReturn($invoice);
        if(!empty($purchasereport)){
            echo $invoice;
       }else{
           
       }
    } 
    public function sales_report_details() {
        if($this->session->userdata('user_login_access') != False) {
            $invoiceID = $this->input->get('id');
            $data['invoice_details'] = $this->sales_model->getByInvoice($invoiceID);
            $this->load->view('backend/invoice_report', $data);

        }

        else{
            redirect(base_url() , 'refresh');
        } 
    }
   public function Purchase_Return_report(){
       // $data['purchasereport'] = $this->sales_model->getPurchaseReport();
        $this->load->view('backend/purchase_report');
    } 

   public function Return_Confirm(){
        $purid      =   $this->input->post('purid');
        $rid      =   'R'.rand(100000,500000);
        $supplier   =   $this->input->post('sid');
        $invoice    =   $this->input->post('invoice');
        $entrydate  =   strtotime(date('Y-m-d'));
        /*$tdiscount  =   round($this->input->post('tdiscount'));*/
        $grandamount =  round($this->input->post('grandamount'));
        $this->load->library('form_validation');
                $data = array();
                $data = array(
                    'r_id' => $rid,
                    'pur_id' => $purid,
                    'sid' => $supplier,
                    'invoice_no' => $invoice,
                    'return_date' => $entrydate,
                    'total_deduction' => $grandamount
                ); 
            $success = $this->purchase_model->Save_Purchase_return($data);
            if($this->db->affected_rows()){
                $purinfo = $this->purchase_model->GePurchaseDetAILSSs($purid);
                $total = $purinfo->gtotal_amount - $grandamount; 
                $data = array();
                $data = array(
                    'gtotal_amount' => $total,
                );
                $success = $this->purchase_model->update_P_balance($purid,$data);                
                foreach($_POST['rqty'] as $row=>$name){
                    if(!empty($_POST['rqty'][$row])){
                $medicine   =   $_POST['mid'][$row];
                $rqty        =   $_POST['rqty'][$row];
                $total      =   $_POST['total'][$row];                   
                    $data = array(
                        'r_id'   =>  $rid,
                        'pur_id'   =>  $purid,
                        'mid'      =>  $medicine,
                        'supp_id'      =>$supplier,
                        'return_qty'      => $rqty,
                        'deduction_amount'   =>  $total
                    );
                $success = $this->purchase_model->Save_Purchase_Retun_History($data);
                    }
                }                 
                foreach($_POST['rqty'] as $row=>$name){
                    if(!empty($_POST['rqty'][$row])){
                $medicine   =   $_POST['mid'][$row];
                $rqty        =   $_POST['rqty'][$row];
                $total      =   $_POST['total'][$row];
                $ph      =   $_POST['ph'][$row];
                $purinfo = $this->purchase_model->GePurchaseHISDetAILSSs($ph);
                $qty = $purinfo->qty - $rqty;        
                $b = $purinfo->total_amount - $total;        
                    $data = array(
                        'qty'      => $qty,
                        'total_amount'   => $b
                    );
                $success = $this->purchase_model->Update_Purchase_History_Details($ph,$data);
                    }
                }                
                foreach($_POST['rqty'] as $row=>$name){
                if(!empty($_POST['rqty'][$row])){
                $medicine   =   $_POST['mid'][$row];
                $rqty        =   $_POST['rqty'][$row];
                $qty        =   $_POST['pqty'][$row];
                $total      =   $_POST['total'][$row];       
                //$medicinestock = $this->purchase_model->getMedicineStock($medicine);
                //$instock = $medicinestock->instock + $qty;
                $medicinestock = $this->purchase_model->getmedicineByMId($medicine);
                $instock = $medicinestock->instock - $rqty;
                    $data = array(
                        'instock'      =>  $instock,
                    );
                $success = $this->purchase_model->Update_Medicine($medicine,$data);
                }
                   
                }

            redirect("sales/Purchase_Return");
            }        
    }
    public function GETSALESrePort(){
       if($this->session->userdata('user_login_access') != False) { 
           $start = strtotime($this->input->post('start'));
           $end = strtotime($this->input->post('end'));
           $invoice_details = $this->sales_model->getByInvoiceFromToEnd($start,$end);
                                            foreach($invoice_details as $value):
                                           $create=  date('l dS \o\f F', strtotime($value->create_date));
                                            echo"<tr>
                                                <td> $create </td>
                                                <td><a href='sales_report_details?id=$value->invoice_no'> $value->invoice_no</a></td>
                                                <td>$value->c_name</td>
                                                <td>
                                                     'TK ' .$value->total_amount
                                                </td>
                                            </tr>";
                                            endforeach;
    }        
    else{
        redirect(base_url() , 'refresh');
    }
    }
    public function GetSalesInvoiceReport(){
        $id = $this->input->get('id');
        $settings   = $this->configuration_model->getAllSettings();
        $invoice = $this->sales_model->getSalesReportForInvoice($id);
        $invoice_details = $this->sales_model->getSalesDetailsForInvoice($id);
        $createdate = date('d/m/Y',$invoice->create_date);
echo " <div class='card-body pos_receipt'>
        <div class='receipt_header'>
          <div class='row'>
          <div class='col-md-12'>
          <p class='company-info'>
            <span>Safeway Pharma</span>
            
            <span style='float:left'>Address: $settings->address</span>
            <span style='float:right'>Contact: $settings->contact</span><br>
            <span>$createdate</span>
          </p>
          </div>
          <div class='col-md-12'>
          <p class='customer-details'>
            <span style='float:left'>#$invoice->cus_id</span>
            <span style='float:right'>Invoice Number: $invoice->invoice_no</span>
            
          </p>
          </div>
          </div>
        </div>
        <div class='receipt_body'>
          <table style='font-size:8px'>
          <thead>
            <th>SL</th>
            <th>Item/Description</th>
            <th>Qty.</th>
            <th>Amount</th>
          </thead> 
          <tbody>";
                $id = 0;
        foreach($invoice_details as $value):
                $id +=1;
            echo"<tr>
            <td>";echo $id; echo"</td>
              <td class='medicine_name'>
                $value->product_name
              </td>
              <td>$value->qty * $value->mrp</td>
              <td>$value->total_price tk.</td>              
            </tr>";
                
                endforeach;
          echo "</tbody>
          
          
            <tr>
            <td></td>
            <td></td>
              <td colspan='1'>Net Due</td>
              <td>$invoice->due_amount tk.</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
              <td colspan='1'>Paid</td>
              <td>$invoice->paid_amount tk.</td>
            </tr>
            <tr>
            <td></td>
            <td></td>
              <td colspan='1'>Total Amount</td>
              <td>$invoice->total_amount tk.</td>
            </tr>
          </table>
        </div>
        <div class='receipt_footer'>
          <span>THANK YOU</span>
        </div>                          
      </div>";        
    }
}